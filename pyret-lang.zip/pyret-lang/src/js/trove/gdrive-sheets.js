({
  requires: [
    { "import-type": "builtin", "name": "table" },
    { "import-type": "builtin", "name": "lists" },
    { "import-type": "builtin", "name": "valueskeleton" }
  ],
  nativeRequires: [
    "pyret-base/js/type-util",
  ],
  provides: {
    values: {
      "create-spreadsheet": "tany",
      "my-spreadsheet": "tany",
      "load-spreadsheet": "tany",
      "open-sheet": "tany",
      "open-sheet-by-index": "tany"
    },
    aliases: {},
    datatypes: {}
  },
  theModule: function(runtime, namespace, uri, table, list, VSlib, t){
    var require = requirejs;
    var Q = require("q");
    var gapi = require("googleapis");
    var GOOGLE_CLIENT_ID="779326781056-fa30bd6vig42q0u7si8vhqc3d639keeq.apps.googleusercontent.com";
    var GOOGLE_CLIENT_SECRET="D-E6llF_yVS1JpADg4IMuAAt";
    var GOOGLE_API_KEY="AIzaSyAvWcv0YnvvHJwWxhqIhqZ6pwqWhvY_zuw";

    ////////////////////////////////////////////////////////////
    //////////////////////////////////// api-wrapper.js, tweaked
    ////////////////////////////////////////////////////////////

    // NOTE: Each of the following should be bound in the global scope:
    //   - `gapi'     : Google API Javascript Client
    //   - `apiKey'   : Google API Key
    //   - `Q'        : Q Promise Framework

    /**
     * The most recently authenticated version of the
     * wrapped Google API
     */
    var gwrap = {
      // Initialize to a dummy method which loads the wrapper
      load: function(params) {
        if (!params || !params.reauth || (params.reauth.immediate === undefined)) {
          throw new Error("Google API Wrapper not yet initialized");
        }
        var ret = Q.defer();
        loadAPIWrapper(false)
          .then(function(gw) {
            // Shallow copy
            var copy = Object.assign({}, params);
            delete copy.reauth;
            gw.load(copy)
              .then(function(loaded) {
                loaded.auth = gw.auth; // NOTE(joe): hmmm
                loaded.hasAuth = function() { return gw.auth !== null; }
                ret.resolve(loaded);
              });
          })
          .fail(function(err) {
            ret.reject(err); 
          });
        return ret.promise;
      },
      request: function() {
        throw new Error("Google API Wrapper not yet initialized");
      }
    };

    /**
     * Reauthenticates the current session.
     * @param {boolean} immediate - Whether the user needs to log in with
     *        Google (if false, the user will receive a refreshed access token).
     * @returns A promise which will resolve following the re-authentication.
     */
    function reauth(immediate) {
      var d = Q.defer();
      if (!immediate) {
        // Need to do a login to get a cookie for this user; do it in a popup
        var w = window.open("/login?redirect=" + encodeURIComponent("/close.html"));
        window.addEventListener('message', function(e) {
          // e.domain appears to not be defined in Firefox
          if ((e.domain || e.origin) === document.location.origin) {
            d.resolve(reauth(true));
          } else {
            d.resolve(null);
          }
        });
      } else {
        // The user is logged in, but needs an access token from our server
        var newToken = $.ajax("/getAccessToken", { method: "get", datatype: "json" });
        newToken.then(function(t) {
          gapi.auth.setToken({ access_token: t.access_token });
          logger.log('login', {user_id: t.user_id});
          d.resolve({ user_id: t.user_id, access_token: t.access_token });
        });
        newToken.fail(function(t) {
          d.resolve(null);
        });
      }
      return d.promise;
    }

    // GAPI Client APIs whose methods have been wrapped with calls to gQ
    // (This is kept in the global state to avoid unneeded reloading)
    var _GWRAP_APIS = {};

    /**
     * Base module for interfacing with Google APIs.
     * Note that any APIs will only be authenticated
     * with the OAuth scopes found in /src/google-auth.js.
     * @param {boolean} immediate - See the description of `immediate`
     *        on `reauth`.
     */
    function loadAPIWrapper(immediate) {


      // Custom error type definitions
      // http://stackoverflow.com/questions/1382107/whats-a-good-way-to-extend-error-in-javascript
      /**
       * Creates a new Google API Error
       * @constructor
       * @param [message] - The error message for this error
       */
      function GoogleAPIError(message) {
        Error.captureStackTrace(this, this.constructor);
        this.name = this.constructor.name;
        this.message = message || "";
      }

      GoogleAPIError.prototype = Object.create(Error.prototype);
      GoogleAPIError.prototype.name = "GoogleAPIError";
      GoogleAPIError.prototype.constructor = GoogleAPIError;

      /**
       * Alias for {@link GoogleAPIError}.
       * @see GoogleAPIError
       */
      var GAPIError = GoogleAPIError;

      /**
       * Creates a new Authentication Error. These are caused by
       * insufficient permissions.
       * @constructor
       * @see GoogleAPIError
       * @param [message] - The error message for this error
       */
      function AuthenticationError(message) {
        this.message = message || "";
      }
      AuthenticationError.prototype = Object.create(GoogleAPIError.prototype);
      AuthenticationError.prototype.name = "AuthenticationError";
      AuthenticationError.prototype.constructor = AuthenticationError;

      /**
       * Creates a new API Response Error. These are caused by invalid/error
       * responses from the Google API; e.g. 404 Not Found errors
       * @constructor
       * @see GoogleAPIError
       * @param [message] - The error message for this error
       */
      function APIResponseError(response) {
        response = response || {};
        this.message = response.message || "";
        this.code = response.code || null;
        this.response = response;
      }
      APIResponseError.prototype = Object.create(GoogleAPIError.prototype);
      APIResponseError.prototype.name = "APIResponseError";
      APIResponseError.prototype.constructor = APIResponseError;

      // Function definitions

      /**
       * Reauthenticates the current session with Google.
       * @see reauth
       * @param {boolean} immediate - DEPRECATED: UNUSED
       */
      function refresh(immediate) {
        if (arguments.length > 0) {
          console.warn("The `immediate` argument to `refresh()` is deprecated.");
        }
        return reauth(true);
      }

      /**
       * Runs the given thunk. If running it results in an
       * authentication failure, the session is re-authorized and the
       * function is run again.
       * @param {function} f - The thunk to run. It should return a promise.
       * @returns The given promise plus any needed re-authentication
       */
      function authCheck(f) {
        function isAuthFailure(result) {
          return result
            && ((result.error && result.error.code && result.error.code === 401)
                || (result.code && result.code === 401));
        }
        var retry = f().then(function(result) {
          if(isAuthFailure(result)) {
            return refresh().then(function(authResult) {
              if(!authResult || authResult.error) {
                return { error: { code: 401, message: "Couldn't re-authorize" } };
              } else {
                return f();
              }
            });
          } else {
            return result;
          }
        });
        return retry.then(function(result) {
          if(isAuthFailure(result)) {
            throw new AuthenticationError("Authentication failure");
          }
          return result;
        });
      }

      /**
       * Wraps the given promise with a check for a failed
       * API response.
       * @param {Promise} p - The promise to wrap
       * @returns {Promise} The wrapped promise
       */
      function failCheck(p) {
        return p.then(function(result) {
          // Network error
          if (result && (typeof result.code === "number") && (result.code >= 400)) {
            console.error("40X Error getting Google API response: ", result);
            throw new APIResponseError(result);
          }
          if (result && result.error) {
            console.error("Error getting Google API response: ", result);
            throw new APIResponseError(result);
          }
          return result;
        });
      }

      /**
       * Wraps the given Google query in a promise
       * @param request - The request object to wrap (made by methods from `gapi')
       * @param {boolean} [skipAuth] - If true, performs the request without
       *        authentication.
       * @returns {Promise} A promise which resolves to the result of the Google query
       */
      function gQ(makeRequest, skipAuth) {
        var oldAccess = gapi.auth.getToken();
        if (skipAuth) { gapi.auth.setToken({ access_token: null }); }
        var ret = failCheck(authCheck(function() {
          var d = Q.defer();
          // TODO: This should be migrated to a promise
          makeRequest().execute(function(result) {
            d.resolve(result);
          });
          return d.promise;
        }));
        if (skipAuth) {
          // NOTE(joe): see discussion at https://github.com/brownplt/code.pyret.org/issues/255
          // for why (A) we do this before the request completes and (B) the
          // setTimeout here is necessary
          setTimeout(function() {
            gapi.auth.setToken(oldAccess);
          });
        }
        return ret;
      }

      var cachedAPIS = [];

      /**
       * Loads the Google API denoted by the given parameters
       * @param {object} params - The designator for the API. Valid fields
       are `name`, `url`, `version`, and `callback`
       * @returns Nothing if `params.callback` is provided, otherwise a promise
       *          which resolves to the loaded API/APIs.
       */
      function loadAPI(params) {
        if (!params) {
          throw new GoogleAPIError("Missing API loading parameters");
        }
        if (params.reauth) {
          if (params.reauth.immediate === undefined) {
            throw new GoogleAPIError("Missing required field to load(): "
                                     + "params.reauth.immediate");
          }
          var reloaded = Q.defer();
          loadAPIWrapper(params.reauth.immediate)
            .then(function(gw) {
              // Shallow copy
              var copy = Object.assign({}, params);
              delete copy.reauth;
              gw.load(copy)
                .then(function(loaded) {
                  reloaded.resolve(loaded);
                });
            });
          return reloaded.promise;
        }
        for (var i = 0; i < cachedAPIS.length; ++i) {
          var cached = cachedAPIS[i];
          if (params.name && (cached.query.name === params.name)) {
            return cached.api;
          } else if (params.url && (cached.query.url === params.url)){
            return cached.api;
          }
        }
        var preKeys = Object.keys(gapi.client);

        function processKey(key) {
          function processObject(obj, dest) {
            Object.keys(obj).forEach(function(key) {
              if (typeof(obj[key]) === "object") {
                dest[key] = {};
                processObject(obj[key], dest[key]);
              } else if (typeof(obj[key]) === "function") {
                // Use one argument, since it seems that's all that's
                // used, and there's no `Function.prototype.apply` equivalent
                // that doesn't change the function's context
                var original = obj[key];
                dest[key] = (function(args, skipAuth) {
                  return gQ(function() { return original(args); }, skipAuth);
                });
              } else {
                dest[key] = obj[key];
              }
            });
          }

          if (key in _GWRAP_APIS) {
            // Do nothing
            return _GWRAP_APIS[key];
          }
          var api = gapi.client[key];
          _GWRAP_APIS[key] = {};
          // NOTE(joe): hack as I'm testing on MS Edge
          if(api !== undefined) {
            processObject(api, _GWRAP_APIS[key]);
          }
          return _GWRAP_APIS[key];
        }

        function processDelta() {
          var newKeys = Object.keys(gapi.client)
              .filter(function(k) {return (preKeys.indexOf(k) === -1);});
          var ret;
          if (newKeys.length > 1) {
            ret = newKeys.map(processKey);
          } else if (params.name && newKeys.length === 0) {
            // Hack to make drive-loading happy on login
            if (gapi.client[params.name]) {
              ret = processKey(params.name);
            }
          } else {
            ret = processKey(newKeys[0]);
          }
          if (!ret) {
            console.warn("loadAPI: Nothing to return!");
          } else {
            cachedAPIS.push({query: params, api: ret});
          }
          return ret;
        }

        var name = params.name || params.url;
        var version = params.version;

        if (params.callback) {
          gapi.client.load(name, version, function() {
            params.callback(processDelta());
          });
          return null;
        } else {
          var ret = Q.defer();
          gapi.client.load(name, version, function() {
            ret.resolve(processDelta());
          });
          return ret.promise;
        }
      }

      var initialAuth = Q.defer(); //reauth(immediate);
      initialAuth.resolve(null);
      return initialAuth.promise.then(function(auth) {
        /**
         * Creates the API Wrapping module to export
         */
        function makeWrapped() {
          this.GoogleAPIError = GoogleAPIError;
          this.GAPIError = GAPIError;
          this.AuthenticationError = AuthenticationError;
          this.APIResponseError = APIResponseError;
          this.load = loadAPI;
          this.withAuth = function(f) {return failCheck(authCheck(f));};
          this.request = (function(params, skipAuth) {
            return gQ(function() { return gapi.client.request(params); }, skipAuth);
          });
          this.auth = auth;
          this.hasAuth = function() { return auth !== null; };
        }

        makeWrapped.prototype = _GWRAP_APIS;

        gwrap = new makeWrapped();
        return gwrap;
      });
    }


    ////////////////////////////////////////////////////////////
    ///////////////////////////////////////// Sheets.js, tweaked
    ////////////////////////////////////////////////////////////
    
    /**
     * Builds a new Google Sheets API interface
     */
    function createAPI(spreadsheets) {

      // Easy toggling
      var _COLUMNS_ONE_INDEXED = true;

      const SHEET_REQ_FIELDS = (function(){
        var sheetData = "data(";
        // Worksheet data
        sheetData += "rowData(values(effectiveFormat/numberFormat,effectiveValue,formattedValue))";
        // Wishful thinking
        sheetData += ",startColumn,startRow)";
        var sheetProperties = "properties(";
        // Grid Properties
        sheetProperties += "gridProperties(columnCount,frozenColumnCount,frozenRowCount,rowCount)";
        // Worksheet title, etc.
        sheetProperties += ",index,sheetId,title)";
        var sheets = "sheets(" + [sheetData,sheetProperties].join(",") + ")";
        return ["properties(defaultFormat,title)",
                sheets,
                "spreadsheetId"].join(',');
      })();
      
      /**
       * Creates a new Google Sheets Error
       * @constructor
       * @param {*} [message] - The contents of this error
       * @param {*} [extra] - Record of extra data to associate with this error
       */
      function SheetsError(message, extra) {
        if (typeof Error.captureStackTrace === 'function') {
          Error.captureStackTrace(this, this.constructor);
        }
        this.name = this.constructor.name;
        this.message = message || "";
        this.extra = extra || {};
      }
      SheetsError.prototype = Object.create(Error.prototype);
      SheetsError.prototype.name = "SheetsError";
      SheetsError.prototype.constructor = SheetsError;

      /**
       * Takes a column and, if it is a numeric index,
       * converts it into A1 notation.
       */
      function colAsString(col) {
        if (!isNaN(col)) {
          // http://stackoverflow.com/questions/181596/how-to-convert-a-column-number-eg-127-into-an-excel-column-eg-aa
          var out = '';
          while(col > 0) {
            var modulo = (col - (_COLUMNS_ONE_INDEXED ? 1 : 0)) % 26;
            out = String.fromCharCode(65 + modulo) + out;
            col = Math.floor((col - modulo) / 26);
          }
          return out;
        } else if (typeof col !== 'string'){
          throw new SheetsError("Invalid column: " + (col ? col.toString() : col));
        } else {
          return col;
        }
      }

      /**
       * Ensures that the given column is in its numeric form
       */
      function colAsNumber(col) {
        if (typeof col === 'string') {
          // https://github.com/python-excel/xlwt/blob/master/xlwt/Utils.py
          var colNum = 0;
          var power = 1;
          for (var i = col.length - 1; i >= 0; --i) {
            colNum += (col.charCodeAt(i) - 65 + 1) * power;
            power *= 26;
          }
          return colNum - (_COLUMNS_ONE_INDEXED ? 1 : 0);
        } else if (isNaN(col)) {
          throw new SheetsError("Invalid column: " + (col ? col.toString() : col));
        } else {
          return col;
        }
      }

      /**
       * Constructs a range from the given parameters in A1 notation
       */
      function makeRange(title, fromCol, fromRow, toCol, toRow) {
        if (fromCol === toCol) {
          fromCol = colAsString(fromCol);
          toCol = fromCol;
        } else {
          fromCol = colAsString(fromCol);
          toCol = colAsString(toCol);
        }
        return title + "!" + fromCol + fromRow + ":" + toCol + toRow;
      }

      const VALUE_TYPES = {
        STRING: 1,
        NUMBER: 2,
        BOOL: 3,
        NONE: 4
      };

      /**
       * Reads in the raw row data from the spreadsheet and
       * returns it such that types match up (i.e. everything
       * in each column has the same type or is null).
       *
       * For an in-depth explanation of the inference rules
       * used here, refer to http://belph.github.io/docs/sheet-infer.pdf
       * (if link is dead, contact Philip (belph)).
       *
       * @param rowData - The raw data to process
       * @param [skipHeaders] - If true, omits the first nonempty row from
       *        the processed data set.
       * @param [onlyInfer] - If given, lists the only columns for which
       *        type inference should take place (effectively, this just
       *        doesn't log any type errors for other columns)
       */
      function unifyRows(rowData, skipHeaders, onlyInfer) {
        var errors = [];
        // Schemas of individual rows
        var rowSchemas = [];
        // Unified table schema
        var schema = [];
        // What column does the data start at?
        var startCol = Infinity;
        var endCol = 0;
        var startRow = 0;

        function processValue(v, idx) {
          if (!v) {
            throw new SheetsError("Internal Error: unifyRows called with no value");
          } else if (!v.effectiveValue) {
            // Empty entry
            return { value: null, type: VALUE_TYPES.NONE };
          }

          // We have an entry; update the start column if needed
          startCol = Math.min(startCol, idx);
          endCol = Math.max(endCol, idx);

          if (v.effectiveValue.numberValue !== undefined) {
            var format = v.effectiveFormat
                && v.effectiveFormat.numberFormat
                && v.effectiveFormat.numberFormat.type;
            var asStr = v.formattedValue
                || v.effectiveValue.numberValue.toString();

            switch(format) {
              // For these formats, use string representation for now.
              // TODO: Make a datetime type for these 
            case "TEXT":
            case "DATE":
            case "TIME":
            case "DATE_TIME":
              return { value: asStr, type: VALUE_TYPES.STRING };
            default:
              return { value: v.effectiveValue.numberValue, type: VALUE_TYPES.NUMBER };
            }
          } else if (v.effectiveValue.boolValue !== undefined) {
            return { value: v.effectiveValue.boolValue, type: VALUE_TYPES.BOOL };
          } else if (v.effectiveValue.errorValue) {
            errors.push("Google Sheets Error: " + v.effectiveValue.errorValue);
            return { value: null, type: VALUE_TYPES.NONE };
          } else {
            return { value: v.formattedValue, type: VALUE_TYPES.STRING };
          }
        }

        // Unzips the results of processValue
        function extractRowSchema(row, rowNum) {
          return row.reduce(function(acc, cur, idx){
            acc.values.push(cur.value);
            acc.schema.push(
              { type: cur.type,
                isOption: (cur.type === VALUE_TYPES.NONE),
                trueRow: rowNum,
                trueCol: idx });
            return acc;
          }, { values: [], schema: []});
        }

        // Type -> String
        function typeName(t) {
          switch(t) {
          case VALUE_TYPES.STRING:
            return "String";
            break;
          case VALUE_TYPES.NUMBER:
            return "Number";
            break;
          case VALUE_TYPES.BOOL:
            return "Bool";
            break;
          case VALUE_TYPES.NONE:
          default: // <- to make linters be quiet
            return "Option";
          }
        }

        // schema1 = accumulated
        function unifySchemas(schema1, schema2, row, index) {
          function logFail() {
            if (onlyInfer && !onlyInfer.includes(schema2.trueCol)) {
              return;
            }
            var trueRow = schema2.trueRow;
            var trueCol = schema2.trueCol;

            var data = rowData[row][index];
            // Surround in quotes for error message clarity
            if (typeof data === "string") {
              data = '"' + data + '"';
            }
            var error = "All items in every column must have the same type. "
                + "We expected to find a " + typeName(schema1.type)
                + " at cell " + colAsString(trueCol + 1) + (trueRow + 1)
                + ", but we instead found this " + typeName(schema2.type)
                + ": " + data + ".";
            if ((schema1.type === VALUE_TYPES.STRING && schema2.type === VALUE_TYPES.NUMBER)
                || (schema1.type === VALUE_TYPES.NUMBER && schema2.type === VALUE_TYPES.STRING)) {
              error += " If you want some Numbers to be read as Strings, you need to format those cells "
                + "in Google Sheets as \"Plain Text\" (Select the cells, click \"Format\", then click \"Number\""
                + ", and then click \"Plain Text\").";
            }
            errors.push(error);
          }
          if (!schema1) { // (T-INTROS)
            return schema2;
          } else if (schema1.type === VALUE_TYPES.NONE) {
            if (schema2.type === VALUE_TYPES.NONE) { // (T-NONE)
              return schema1;
            } else { // (T-OPTION-1)
              schema2.isOption = true;
              return schema2;
            }
          } else if (schema1.isOption) { // (T-OPTION-3)
            if (schema2.type === VALUE_TYPES.NONE || schema2.type === schema1.type) {
              return schema1;
            } else { // (T-ERROR-1)
              logFail();
              // Continue to expect accumulated schema
              return schema1;
            }
          } else if (schema2.type === VALUE_TYPES.NONE) { // (T-OPTION-2)
            schema1.isOption = true;
            return schema1;
          } else if (schema1.type === schema2.type) { // (T-CHECK)
            return schema1;
          } else { // (T-ERROR-2)
            logFail();
            // Continue to expect accumulated schema
            return schema1;
          }
        }

        var foundFirstRow = false;
        var foundHeaders = false;
        var emptyRows = [];
        rowData = rowData.map(function(row, rowNum) {
          if (row.values
              && (row.values.length > 0)
              && (row.values.some(function(v){return v.effectiveValue !== undefined;}))) {
            if (!foundHeaders && skipHeaders) {
              foundHeaders = true;
              startRow += 1;
              rowSchemas.push([]);
              return [];
            }
            foundFirstRow = true;
            var extracted = extractRowSchema(row.values.map(processValue), rowNum);
            row.values = extracted.values;
            rowSchemas.push(extracted.schema);
            return row.values;
          } else if (!foundFirstRow) {
            startRow += 1;
          } else {
            emptyRows.push(rowNum);
          }
          rowSchemas.push([]);
          return [];
        });
        // Remove empty rows (reverse order to preserve index locations)
        for (var i = emptyRows.length - 1; i >= 0; --i) {
          rowData.splice(emptyRows[i], 1);
          rowSchemas.splice(emptyRows[i], 1);
        }
        rowData.splice(0, startRow);
        rowSchemas.splice(0, startRow);
        var tableWidth = (endCol - startCol) + 1;
        // Trim/pad remaining rows to uniform shape
        for (var i = 0; i < rowData.length; ++i) {
          // Trim off any leading columns
          rowData[i] = rowData[i].slice(startCol, endCol + 1);
          rowSchemas[i] = rowSchemas[i].slice(startCol, endCol + 1);
          // Pad out any missing trailing columns
          for (var j = rowData[i].length; j < tableWidth; ++j) {
            rowData[i][j] = null;
            rowSchemas[i].push({ type: VALUE_TYPES.NONE, isOption: false });
          }
        }
        // Unify schemas
        for (var i = 0; i < rowSchemas.length; ++i) {
          for (var j = 0; j < Math.max(schema.length, rowSchemas[i].length); ++j) {
            schema[j] = unifySchemas(schema[j], rowSchemas[i][j], i, j);
          }
        }
        var ret = { values: rowData, schema: schema, startCol: startCol };
        if (errors.length > 0) {
          ret.errors = errors;
        }
        return ret;
      }

      /**
       * Creates a new Spreadsheet object, representing
       * a Google Sheets spreadsheet.
       * @constructor
       * @param {Object} data - The JSON response from Google representing
       this spreadsheet.
      */
      function Spreadsheet(data) {
        this.id = data.spreadsheetId;
        this.title = data.properties.title;
        this.defaultFormat = data.properties.defaultFormat || {};
        data.sheets = data.sheets || [];
        this.worksheetsInfo = [];
        this.worksheets = data.sheets.map(function(wsdata) {
          return new Worksheet(this, wsdata);
        }, this);
      }

      /**
       * Internal method for looking up Worksheet information
       * via the name of the worksheet.
       * @param {string} name - The name of the worksheet to look up
       */
      Spreadsheet.prototype.lookupInfoByName = function(name) {
        var worksheetIdx = -1;
        for (var i = 0; i < this.worksheetsInfo.length; ++i) {
          var info = this.worksheetsInfo[i];
          if (info.properties.title === name) {
            worksheetIdx = i;
            break;
          }
        }
        if (worksheetIdx === -1) {
          throw new SheetsError("No worksheet with name \"" + name + "\"");
        } else {
          return this.worksheetsInfo[worksheetIdx];
        }
      };

      /**
       * Internal method for looking up worksheet information
       * via the index of the worksheet.
       * @param {number} worksheetIdx - The index of the worksheet to look up
       */
      Spreadsheet.prototype.lookupInfoByIndex = function(worksheetIdx) {
        if (worksheetIdx >= this.worksheetsInfo.length) {
          throw new SheetsError("No worksheet with index " + worksheetIdx + "");
        } else {
          return this.worksheetsInfo[worksheetIdx];
        }
      };

      /**
       * Returns the worksheet in this spreadsheet at the specified
       * index.
       * @param {number} worksheetIdx - The index of the worksheet to return
       * @param {boolean} skipHeaders - Indicates whether or not header rows
       *        should be skipped (ignored if this worksheet has been previously loaded)
       * @param {integer[]} [onlyInfer] - If given, will only perform type inference
       *        on the given columns (i.e. does not report type errors on other columns)
       */
      Spreadsheet.prototype.getByIndex = function(worksheetIdx, skipHeaders, onlyInfer) {
        // Performs validation on index
        this.lookupInfoByIndex(worksheetIdx);
        var ret = this.worksheets[worksheetIdx];
        ret.init(skipHeaders, onlyInfer);
        return ret;
      };

      /**
       * Returns the worksheet in this spreadsheet with the
       * given name.
       * @param {string} name - The name of the worksheet to return
       * @param {boolean} skipHeaders - Indicates whether or not header rows
       *        should be skipped (ignored if this worksheet has been previously loaded)
       * @param {integer[]} [onlyInfer] - If given, will only perform type inference
       *        on the given columns (i.e. does not report type errors on other columns)
       */
      Spreadsheet.prototype.getByName = function(name, skipHeaders, onlyInfer) {
        var info = this.lookupInfoByName(name);
        var ret = this.worksheets[info.properties.index];
        ret.init(skipHeaders, onlyInfer);
        return ret;
      };

      /**
       * Adds a worksheet to this spreadsheet with the given title
       * and (optionally) index
       * @param {string} name - The title of the new worksheet
       * @param {number} [index] - The index to place the new sheet at.
       *        By default, the worksheet is added after all existing sheets.
       */
      Spreadsheet.prototype.addWorksheet = function(name, index) {
        var request = {addSheet:
                       {properties:
                        {title: name}}};
        if (index !== undefined) {
          request.addSheet.properties.index = index;
        }
        return spreadsheets.batchUpdate({
          spreadsheetId: this.id,
          resource: {
            requests: [request]
          }
        })
          .then((function(data) {
            return spreadsheets.get({
              spreadsheetId: this.id,
              ranges: name,
              fields: SHEET_REQ_FIELDS
            });}).bind(this))
          .then((function(data) {
            if (!data.sheets || (data.sheets.length === 0)) {
              throw new SheetsError("Failed to add worksheet: \"" + name + "\"");
            }
            var ret = new Worksheet(this, data.sheets[0]);
            ret.init(false);
            return ret;
          }).bind(this))
          .fail(function(err) {
            if (err.message && /already exists/.test(err.message)) {
              throw new SheetsError("A sheet with name \"" + name + "\""
                                    + " already exists in this spreadsheet.");
            } else {
              throw err;
            }
          });
      };

      /**
       * Internal method for deleting worksheets
       * @param {number} id - The ID of the worksheet to delete
       */
      Spreadsheet.prototype.deleteSheetById = function(id) {
        return spreadsheets.batchUpdate({
          spreadsheetId: this.id,
          resource: {
            requests: [{deleteSheet: {sheetId: id}}]
          }
        })
          .then(function(_) { return true; })
          .fail(function(err) {
            if (err.message && /sheet with ID.*does not exist/.test(err.message)) {
              throw new SheetsError("A sheet with ID \"" + id + "\" "
                                    + "does not exist in this spreadsheet.");
            } else {
              throw err;
            }
          });
      };

      /**
       * Deletes the worksheet from this spreadsheet with
       * the given name
       * @param {string} name - The name of the worksheet to delete
       */
      Spreadsheet.prototype.deleteSheetByName = function(name) {
        return this.deleteSheetById(this.lookupInfoByName(name).properties.sheetId)
          .fail(function(err) {
            if (err.message && /does not exist in this spreadsheet/.test(err.message)) {
              throw new SheetsError(
                err.message.replace(/ID "[^"]*"/, "name \"" + name + "\""));
            } else {
              throw err;
            }
          });
      };

      /**
       * Deletes the worksheet from this spreadsheet at
       * the given index
       * @param {number} idx - The index of the sheet to delete
       */
      Spreadsheet.prototype.deleteSheetByIndex = function(idx) {
        // lookupInfoByIndex does error handling
        return this.deleteSheetById(this.lookupInfoByIndex(idx).properties.sheetId);
      };

      /**
       * Constructs a new Worksheet object, representing
       * a worksheet in a {@link Spreadsheet}.
       * @constructor
       * @param {Object} data - The JSON object describing the worksheet
       *        (returned from the Google Sheets API)
       */
      function Worksheet(spreadsheet, data) {
        if (!data) {
          throw new SheetsError("Worksheet: Internal Error: No data. "
                                + "Please report this error to the developers.");
        } else if (!data.properties) {
          throw new SheetsError("Worksheet: Internal Error: No properties. "
                                + "Please report this error to the developers.");
        }
        this.id = data.properties.sheetId;
        this.title = data.properties.title;
        this.rows = data.properties.gridProperties.rowCount;
        this.cols = data.properties.gridProperties.columnCount;
        this.index = data.properties.index;
        spreadsheet.worksheetsInfo[this.index] = { properties: data.properties };
        this.cache = [];
        this.spreadsheet = spreadsheet;
        this.rawData = data;
        this.listener = {
          handleEvent: (function(){
            return this.flushCache(true);
          }).bind(this)
        };
        /*
        if (window === undefined) {
          console.warn("No window detected. Sheets may fall out of sync.");
          this.useTimer = false;
        } else {
          // Sync with Google Sheets server on save
          window.addEventListener('pyret-save', this.flushCache.bind(this), false);
          this.useTimer = true;
        }
        */
      }

      /**
       * Reads in row data from the Google Sheets API response,
       * runs the type inference scheme on it, and populates this
       * worksheet's data.
       * @param {boolean} skipHeaders - Indicates whether or not header rows
       *        should be skipped (ignored if this worksheet has been previously loaded)
       * @param {integer[]} [onlyInfer] - If given, will only perform type inference
       *        on the given columns (i.e. does not report type errors on other columns)
       */
      Worksheet.prototype.init = function(skipHeaders, onlyInfer) {
        if ((this.hasHeaders !== undefined)
            && (this.hasHeaders !== !skipHeaders)) {
          throw new SheetsError("Attempted to load worksheet with"
                                + (skipHeaders ? "out" : "")
                                + " headers, but worksheet was already previously"
                                + " loaded with" + (skipHeaders ? "" : "out")
                                + " headers.");
        } else if (this.data !== undefined) {
          return;
        }
        var data = this.rawData;
        this.hasHeaders = !skipHeaders;
        if (!(data.data && data.data[0] && data.data[0].rowData)) {
          this.data = [];
          this.startCol = 0;
          this.schema = [];
        } else {
          var unified = unifyRows(data.data[0].rowData, skipHeaders, onlyInfer);
          this.startCol = unified.startCol;
          this.data = unified.values;
          this.schema = unified.schema;
          // Might be undefined
          this.typeErrors = unified.errors;
          if (!this.data) {
            throw new SheetsError("Worksheet: Internal Error: "
                                  + "Type-check yielded no values. "
                                  + "Please report this error to the developers.");
          } else if (!this.schema) {
            throw new SheetsError("Worksheet: Internal Error: "
                                  + "Type-check yielded no schema. "
                                  + "Please report this error to the developers.");
          }
        }
      };

      /**
       * Clears this worksheet's timers (for pushing data to the server)
       */
      Worksheet.prototype.clearTimer = function() {
        if (this.useTimer && (this.timeoutId !== undefined)) {
          window.removeEventListener("beforeunload", this.listener);
          window.clearTimeout(this.timeoutId);
          this.timeoutId = undefined;
        }
      };

      /**
       * Sets this worksheet's timers (for pushing data to the server).
       * If any timers already exist, they are replaced by the new ones.
       *
       * The rationale here is that a large number of updates can be batched
       * together, and, if none are received after 10sec, it's assumed that
       * the updates are done, so we can go ahead and sync.
       */
      Worksheet.prototype.resetTimer = function() {
        if (this.useTimer) {
          this.clearTimer();
          window.addEventListener("beforeunload", this.listener);
          this.timeoutId = window.setTimeout(this.flushCache.bind(this), 10000);
        }
      };

      /**
       * Returns the cell at the given position in this worksheet
       * @param {string|number} col - The column to retrieve
       * @param {number} row - The row to retrieve
       */
      Worksheet.prototype.getCellAt = function(col, row) {
        return this.getCellRange(col, row, col, row)
          .then(function(arr) { return arr[0][0]; });
      };

      /**
       * Sets the cell at the given position in this worksheet
       * @param {string|number} col - The column to set
       * @param {number} row - The row to set
       * @param {*} val - The value to set the cell to
       */
      Worksheet.prototype.setCellAt = function(col, row, val) {
        return this.setCellRange(col, row, col, row, [[val]]);
      };

      /**
       * Sets the given cell range in this worksheet
       * @param {string|number} fromCol - The starting column of the range
       * @param {number} fromRow - The starting row of the range
       * @param {string|number} toCol - The ending column of the range
       * @param {number} toRow - The ending row of the range
       * @param {*[][]} values - The values to set in the worksheet
       */
      Worksheet.prototype.setCellRange = function(fromCol, fromRow, toCol, toRow, values) {
        var range = makeRange(this.title, fromCol, fromRow, toCol, toRow);
        this.cache.push({
          range: range,
          majorDimension: "ROWS",
          values: values
        });
        this.resetTimer();
        return true;
      };

      /**
       * Pushes all pending changes to the Google Sheets server.
       * @param {bool} noRefresh - If true, will not reload data
       *        (useful for pre-closing pushes)
       */
      Worksheet.prototype.flushCache = function(noRefresh) {
        this.clearTimer();
        // If we're not waiting to set anything, bail out.
        if (this.cache.length === 0) {
          return Q(this);
        } else {
          // We're waiting to set some values, so set them.
          var promise = spreadsheets.values.batchUpdate({
            spreadsheetId: this.spreadsheet.id,
            resource: {
              data: this.cache
            }
          });
          this.cache = [];
          return promise.then(noRefresh ?
                              function(){return this;}.bind(this)
                              : this.refresh.bind(this));
        }
      };

      /**
       * Returns all cells in this worksheet
       */
      Worksheet.prototype.getAllCells = function() {
        return this.flushCache().then((function(){
          return this.data;
        }).bind(this));
      };

      /**
       * Returns the given range of cells in this worksheet (inclusive)
       * @param {string|number} fromCol - The column to start at
       * @param {number} fromRow - The row to start at
       * @param {string|number} toCol - The column to end at
       * @param {number} toRow - The row to end at
       */
      Worksheet.prototype.getCellRange = function(fromCol, fromRow, toCol, toRow) {
        fromCol = colAsNumber(fromCol);
        toCol = colAsNumber(toCol);
        return this.flushCache().then((function(){
          return this.data.map((function(row) {
            return row.slice(fromCol - this.startCol, (toCol - this.startCol) + 1);
          }).bind(this)).slice(fromRow - 1, toRow);
        }).bind(this));
      };

      /**
       * Updates the name of this worksheet to the given name
       * @param {string} name - The new name of this worksheet
       */
      Worksheet.prototype.updateName = function(name) {
        var ret = spreadsheets.batchUpdate({
          spreadsheetId: this.spreadsheet.id,
          resource: {
            requests: [
              {updateSheetProperties: {properties: {title: name}, fields: "title"}}
            ]
          }
        });
        ret.then((function(_) { this.title = name; }).bind(this));
        return ret;
      };

      /**
       * Fetches the latest worksheet contents from the
       * Google Sheets server.
       */
      Worksheet.prototype.refresh = function() {
        return spreadsheets.get({
          spreadsheetId: this.spreadsheet.id,
          ranges: this.title,
          fields: SHEET_REQ_FIELDS
        }).then((function(data){
          if (!data.sheets || !data.sheets[0]
              || !data.sheets[0].data
              || !data.sheets[0].data[0]
              || !data.sheets[0].data[0].rowData) {
            throw new SheetsError("Worksheet data not returned by Google. "
                                  + "Please report this error to the developers.");
          }
          // Re-unify
          this.rawData = data.sheets[this.index];
          this.init();
          return this;
        }).bind(this));
      };

      /**
       * Loads the spreadsheet with the given id
       */
      Spreadsheet.fromId = function(id) {
        return spreadsheets.get({
          spreadsheetId: id,
          fields: SHEET_REQ_FIELDS
        }).then(function(data) { return new Spreadsheet(data.data); },
                function(err) {
                  throw new SheetsError("No Spreadsheet with id \"" + id + "\" found");
                });
      };
      
      /**
       * Loads a spreadsheet from the given file object
       * @param file - A file object (as returned from `drive.js`)
       */
      Spreadsheet.fromFile = function(file) {
        return Spreadsheet.fromId(file.getUniqueId());
      };

      return {
        createSpreadsheet: function(name) {
          var opts = {};
          opts.mimeType = 'application/vnd.google-apps.spreadsheet';
          opts.fileExtension = false;
          var ret = Q.defer();
          storageAPI
            .then(function(api){
              return api.createFile(name, opts);
            })
            .then(function(file) {
              return spreadsheets.get({
                spreadsheetId: file.getUniqueId()
              });
            })
            .then(function(data) {
              ret.resolve(new Spreadsheet(data));
            })
            .fail(ret.reject);
          return ret.promise;
        },
        loadSpreadsheetByName: function(name) {
          return storageAPI.then(function(api) {
            return api.getFileByName(name);
          }).then(function(res) {
            if (res.length === 0) {
              throw new SheetsError("No spreadsheet named \"" + name + "\" found.");
            } else {
              return res[0];
            }
          }).then(Spreadsheet.fromFile);
        },
        loadSpreadsheetById: function(id) {
          return Spreadsheet.fromId(id);
        },
        TYPES: VALUE_TYPES
      };
    }

    function createSheetsAPI(immediate) {
      var ret = Q.defer();
      gwrap.load({url: 'https://sheets.googleapis.com/$discovery/rest?version=v4',
                  reauth: {
                    immediate: immediate
                  },
                  callback: function(sheets) {

                    // NOTE(joe, July 13 2017): The load interface seems to
                    // inconsistently (perhaps depending on state w/Google login?)
                    // return an array and a single value here.  The array contains
                    // both the spreadsheets API object and the Google Plus API
                    // object, which was added recently to get user emails for
                    // display.  I haven't dug into why this happens (the
                    // processDelta() function in the load API is responsible for
                    // these return values), but this fix isn't completely
                    // senseless and works.

                    if(Array.isArray(sheets)) {
                      for(var i = 0; i < sheets.length; i += 1) {
                        if(sheets[i].spreadsheets) {
                          ret.resolve(createAPI(sheets[i].spreadsheets));
                          return;
                        }
                      }
                      ret.reject("Sheets could not load");
                    }
                    else {
                      ret.resolve(createAPI(sheets.spreadsheets));
                    }
                  }});
      return ret.promise;
    }

    var sheetsAPI = Q.defer();
    sheetsAPI.resolve(createAPI(gapi.google.sheets({
      version: 'v4',
      auth: GOOGLE_API_KEY,
    }).spreadsheets));
    sheetsAPI = sheetsAPI.promise;
    // sheetsAPI = createSheetsAPI(true);

    var List = function(thing) { 
      return t.tyapp(t.libName("lists", "List"), [thing]);
    };
    // Tables not yet in the Typechecker, AFAIK
    /*
    var TableT = t.any;
    var SpreadsheetT = t.record({
      'sheet-list': List(t.string),
      'sheet-by-name': TableT,
      'sheet-by-index': TableT,
      'delete-sheet-by-name': t.nothing,
      'delete-sheet-by-index': t.nothing,
      'add-sheet': TableT
    });
    var types = {
      values: {
        "create-spreadsheet": t.arrow([t.string], SpreadsheetT),
        "my-spreadsheet": t.arrow([t.string], SpreadsheetT),
        "load-spreadsheet": t.arrow([t.string], SpreadsheetT)
        //"load-spreadsheet-url": t.arrow([t.string], SpreadsheetT)
      },
      aliases: {},
      datatypes: {}
    };*/
    
    var F = runtime.makeFunction;
    var O = runtime.makeObject;
    var VS = runtime.getField(VSlib, "values");

    var None = runtime.ffi.makeNone;
    var Some = runtime.ffi.makeSome;

    var SHEET_TYPES;

    function applyBrand(brand, val) {
      return runtime.getField(brand, "brand").app(val);
    }

    function hasBrand(brand, val) {
      return runtime.getField(brand, "test").app(val);
    }

    var brandWS = runtime.namedBrander("sheet", ["worksheet: worksheet brander"]);
    var brandSS = runtime.namedBrander("spreadsheet", ["spreadsheet: spreadsheet brander"]);

    function isSpreadsheet(val) {
      return hasBrand(brandSS, val);
    }

    function isWorksheet(val) {
      return hasBrand(brandWS, val);
    }

    var checkSpreadsheet = runtime.makeCheckType(isSpreadsheet, "Spreadsheet");
    var checkWorksheet = runtime.makeCheckType(isWorksheet, "Worksheet");

    function loadWorksheet(loader, buildFun) {
      buildFun = buildFun || worksheetToTable;
      function doLoadWorksheet() {
        return runtime.pauseStack(function(resumer) {
          function handleError(err) {
            if (runtime.isPyretException(err)) {
              resumer.error(err);
            } else {
              if (err && err.message) err = err.message;
              resumer.error(runtime.ffi.makeMessageException(err));
            }
          }
          try {
            var p = buildFun(loader());
            p.then(function(thunk) {
              resumer.resume(thunk);
            });
            p.catch(handleError);
          } catch (err) {
            handleError(err);
          }
        });
      }
      return runtime.safeCall(doLoadWorksheet, function(thunk) {
        return thunk();
      }, "gdrive-sheets:loadWorksheet:doLoadWorksheet");
    }

    function deleteWorksheet(deleter) {
      return runtime.pauseStack(function(resumer) {
        function handleError(err) {
          if (runtime.isPyretException(err)) {
            resumer.error(err);
          } else {
            if (err && err.message) err = err.message;
            resumer.error(runtime.ffi.makeMessageException(err));
          }
        }
        try {
          deleter().then(function(_) {
            resumer.resume(runtime.makeNothing());
          }).catch(handleError);
        } catch (err) {
          handleError(err);
        }
      })
    }

    function addWorksheet(adder) {
      function doAdd() {
        return runtime.pauseStack(function(resumer) {
          function handleError(err) {
            if (runtime.isPyretException(err)) {
              resumer.error(err);
            } else {
              if (err && err.message) err = err.message;
              resumer.error(runtime.ffi.makeMessageException(err));
            }
          }
          try {
            adder().then(worksheetToTable).then(function(thunk) {
              resumer.resume(thunk);
            }).catch(handleError);
          } catch (err) {
            handleError(err);
          }
        });
      }
      return runtime.safeCall(doAdd, function(thunk) {
        return thunk();
      }, "gdrive-sheets:addWorksheet:doAdd");
    }

    function worksheetToTable(ws, colNames) {
      var cols = colNames ? colNames.length : ws.cols;
      if (!colNames) {
        if (cols <= 26) {
          colNames = Array.apply(null, Array(cols)).map(function (_, i) {
            return String.fromCharCode(65 + i);});
        } else {
          var i = 26;
          var j = 0;
          var k = 0;
          var curChar = String.fromCharCode(65 + j);
          var suffix = '';
          colNames = Array.apply(null, Array(26)).map(function (_, i) {
            return String.fromCharCode(65 + i);});
          var startOff = 0;
          var startLen = 26;
          // Convoluted way of generating ['A', 'B', ..., 'AA', 'AB', ...]
          while(++i <= cols) {
            if (k >= startLen) {
              ++j;
              j = j % 26;
              if (j === 0) {
                startOff += startLen;
                startLen *= 26;
              }
              k = startOff;
              curChar = String.fromCharCode(65 + j);
            }
            colNames.push(curChar + colNames[k]);
            ++k;
          }
        }
      }
      function applyArray(arr) {
        return function(v, i) {
          return arr[i](v);
        };
      }
      function schemaToConstructor(schema) {
        if (schema.isOption) {
          var typeConstructor = schemaToConstructor({
            type: schema.type, isOption: false
          });
          return function(v) {
            if (v === null) {
              return None();
            } else {
              return Some(typeConstructor(v));
            }
          };
        } else {
          switch (schema.type) {
          case SHEET_TYPES.STRING:
            return runtime.makeString;
          case SHEET_TYPES.NUMBER:
            return runtime.makeNumber;
          case SHEET_TYPES.BOOL:
            return runtime.makeBoolean;
          case SHEET_TYPES.NONE:
          default:
            return function(v) {
              if (v !== null) {
                throw new Error(
                  "Unknown type for sheet value " + v.toString());
              } else {
                return None();
              }
            };
          }
        }
      }
      return ws.getAllCells().then(function(data) {
        if (ws.typeErrors && (ws.typeErrors.length > 0)) {
          var errmsgs = ws.typeErrors.map(runtime.ffi.makeMessageException);
          errmsgs.unshift(
            runtime.ffi.makeMessageException("There were worksheet importing errors."));
          runtime.ffi.throwMultiErrorException(runtime.ffi.makeList(errmsgs));
        } else if (data.length === 0) {
          return function() { runtime.getField(table, "makeTable")([], []); };
        } else {
          var constructors = ws.schema.map(schemaToConstructor);
          var width = data[0].length;
          data.forEach(function(row) {
            if (row.length !== width) {
              throw new Error(
                "Internal Error: Expected row of length " + width.toString()
                  + ", but found row of length " + row.length.toString()
                  + ". Please report this error to the developers.");
            }
          });
          colNames = colNames.slice(ws.startCol, ws.startCol + width);
          var outData = (new Array(data.length)).fill().map(function(){
            return new Array(width);
          });
          return function() {
            return runtime.safeCall(function() {
              return runtime.eachLoop(runtime.makeFunction(function(i) {
                return runtime.eachLoop(runtime.makeFunction(function(curIdx) {
                  return runtime.safeCall(function() {
                    return constructors[curIdx](data[i][curIdx]);
                  }, function(result) {
                    outData[i][curIdx] = result;
                    return runtime.nothing;
                  }, "gdrive-sheets:worksheetToTable:constructCell");
                }), 0, width);
              }), 0, data.length);
            }, function(_) {
              return table.makeTable(colNames, outData);
            }, "gdrive-sheets:worksheetToTable:constructValues");
          };
        }
      });
    }

    /**
     * Constructs a new Pyret Table Loader which is bound to
     * the worksheet associated with the given function.
     * @param load - A function which accepts a list of column indices
     *        needing type inference and returns the worksheet object
     */
    function makeSheetLoader(load) {
      function doLoad(colNames, sanitizers) {
        runtime.ffi.checkArity(2, arguments, "load", false);
        runtime.checkArray(colNames);
        runtime.checkArray(sanitizers);
        sanitizers = sanitizers.map(runtime.extractLoaderOption);
        var needsInference = [];
        var resolved = [];
        for (var i = 0; i < colNames.length; ++i) {
          var matching = sanitizers.find(function(s) {
            return s.col == colNames[i];
          });
          if (matching === undefined) {
            needsInference.push({name: colNames[i], index: i});
          } else {
            resolved.push({name: colNames[i], sanitizer: matching.sanitizer, index: i});
          }
        }
        return loadWorksheet(function() {
          return load(needsInference.map(function(o){ return o.index; }));
        }, function(ws) {
          return worksheetToLoadedTable(ws, resolved, needsInference);
        });
      }
      return O({
        'load': F(doLoad)
      });
    }

    function worksheetToLoadedTable(ws, resolved, needsInference) {

      function schemaToSanitizer(schema) {
        var sanitizer;
        switch(schema.type) {
        case SHEET_TYPES.STRING:
          sanitizer = runtime.builtin_sanitizers.string;
          break;
        case SHEET_TYPES.NUMBER:
          sanitizer = runtime.builtin_sanitizers.strict_num;
          break;
        case SHEET_TYPES.BOOL:
          sanitizer = runtime.builtin_sanitizers.bool;
          break;
        case SHEET_TYPES.NONE:
        default:
          sanitizer = runtime.builtin_sanitizers.empty_only;
        }
        if (schema.isOption) {
          sanitizer = runtime.builtin_sanitizers.option.app(sanitizer);
        }
        return sanitizer;
      }

      function wrapCell(v) {
        if (v === null) {
          return runtime.makeCEmpty();
        } else if (typeof v === 'string') {
          return runtime.makeCStr(runtime.makeString(v));
        } else if (typeof v === 'number') {
          return runtime.makeCNum(runtime.makeNumber(v));
        } else if (typeof v === 'boolean') {
          return runtime.makeCBool(runtime.makeBoolean(v));
        } else {
          runtime.ffi.throwMessageException(
            "Internal Error: wrapCell got unknown value: "
              + ((v && v.toString) ? v.toString() : v));
        }
      }

      return ws.getAllCells().then(function(data) {
        if (ws.typeErrors && (ws.typeErrors.length > 0)) {
          var errmsgs = ws.typeErrors.map(runtime.ffi.makeMessageException);
          errmsgs.unshift(runtime.ffi.makeMessageException(
            "There were worksheet importing errors."));
          runtime.ffi.throwMultiErrorException(runtime.ffi.makeList(errmsgs));
        } else if (data.length === 0) {
          runtime.ffi.throwMessageException("Empty worksheets cannot be imported.");
        } else {
          var width = data[0].length;
          // resolved and needsInference are *sorted by index*
          var expectedLength = resolved.length + needsInference.length;
          if (expectedLength !== width) {
            runtime.ffi.throwMessageException("Loaded worksheet has "
                                              + ws.cols
                                              + " columns, but "
                                              + expectedLength
                                              + " column names were given.");
          }
          data.forEach(function(row) {
            if (row.length !== width) {
              throw new Error(
                "Internal Error: Expected row of length " + width.toString()
                  + ", but found row of length " + row.length.toString()
                  + ". Please report this error to the developers.");
            }
          });

          var fullySanitized = [];
          var rIdx = resolved.length - 1;
          var nIdx = needsInference.length - 1;
          while (rIdx >= 0 && nIdx >= 0) {
            if (resolved[rIdx].index > needsInference[nIdx].index) {
              fullySanitized.push(resolved[rIdx--]);
            } else {
              var colIdx = needsInference[nIdx].index;
              needsInference[nIdx].sanitizer = schemaToSanitizer(ws.schema[colIdx]);
              fullySanitized.push(needsInference[nIdx--]);
            }
          }
          // At most one of the following two loops will run
          while (rIdx >= 0) {
            fullySanitized.push(resolved[rIdx--]);
          }
          while (nIdx >= 0) {
            var colIdx = needsInference[nIdx].index;
            needsInference[nIdx].sanitizer = schemaToSanitizer(ws.schema[colIdx]);
            fullySanitized.push(needsInference[nIdx--]);
          }
          fullySanitized = fullySanitized.reverse();
          var outData = (new Array(data.length)).fill().map(function(){
            return new Array(width);
          });
          return function() {
            return runtime.safeCall(function() {
              return runtime.eachLoop(runtime.makeFunction(function(i) {
                return runtime.eachLoop(runtime.makeFunction(function(curIdx) {
                  return runtime.safeCall(function() {
                    return wrapCell(data[i][curIdx]);
                  }, function(result) {
                    outData[i][curIdx] = result;
                    return runtime.nothing;
                  }, "gdrive-sheets:worksheetToLoadedTable:constructCell");
                }), 0, width)
              }), 0, data.length);
            },
            function(_) {
              return runtime.makeLoadedTable(fullySanitized, outData);
            }, "gdrive-sheets:worksheetToLoadedTable:constructValues");
          }
        }
      });
    }

    function spreadsheetSheetByName(ss, name, skipHeaders) {
      runtime.ffi.checkArity(3, arguments, "open-sheet", false);
      checkSpreadsheet(ss);
      runtime.checkString(name);
      runtime.checkBoolean(skipHeaders);
      return runtime.getField(ss, 'sheet-by-name').app(name, skipHeaders);
    }

    function spreadsheetSheetByIndex(ss, idx, skipHeaders) {
      runtime.ffi.checkArity(3, arguments, "open-sheet-by-index", false);
      checkSpreadsheet(ss);
      runtime.checkNumber(idx);
      runtime.checkBoolean(skipHeaders);
      return runtime.getField(ss, 'sheet-by-index').app(idx, skipHeaders);
    }

    function makePyretSpreadsheet(ss) {
      function rawSheetNames() {
        return ss.worksheetsInfo.map(function(ws) { return runtime.makeString(ws.properties.title); });
      }
      function sheetNames() {
        runtime.ffi.checkArity(0, arguments, "sheet-names", true);
        return runtime.ffi.makeList(rawSheetNames());
      }
      
      function sheetByName(name, skipHeaders) {
        runtime.ffi.checkArity(2, arguments, "sheet-by-name", true);
        runtime.checkString(name);
        runtime.checkBoolean(skipHeaders);
        return makeSheetLoader(function(onlyInfer) {
          return ss.getByName(name, skipHeaders, onlyInfer);
        });
        //return loadWorksheet(function(){return ss.getByName(name, skipHeaders);});
      }
      
      function sheetByPos(idx, skipHeaders) {
        runtime.ffi.checkArity(2, arguments, "sheet-by-index", true);
        runtime.checkNumber(idx);
        runtime.checkBoolean(skipHeaders);
        return makeSheetLoader(function(onlyInfer) {
          return ss.getByIndex(idx, skipHeaders, onlyInfer);
        });
        //return loadWorksheet(function(){return ss.getByIndex(idx, skipHeaders);});
      }
      function deleteSheetByName(name) {
        runtime.ffi.checkArity(1, arguments, "delete-sheet-by-name", true);
        runtime.checkString(name);
        return deleteWorksheet(function(){return ss.deleteByName(name);});
      }
      function deleteSheetByPos(idx) {
        runtime.ffi.checkArity(1, arguments, "delete-sheet-by-index", true);
        runtime.checkNumber(idx);
        return deleteWorksheet(function(){return ss.deleteByIndex(idx);});
      }
      function addSheet(name) {
        runtime.ffi.checkArity(1, arguments, "add-sheet", true);
        runtime.checkString(name);
        return addWorksheet(function(){return ss.addWorksheet(name);});
      }

      return applyBrand(brandSS, O({
        'sheet-names': F(sheetNames),
        'sheet-by-name': F(sheetByName),
        'sheet-by-index': F(sheetByPos),
        'delete-sheet-by-name': F(deleteSheetByName),
        'delete-sheet-by-index': F(deleteSheetByPos),
        'add-sheet': F(addSheet),
        '_output': runtime.makeMethod0(function(self) {
          return runtime.getField(VS, "vs-constr").app(
            "spreadsheet",
            runtime.ffi.makeList(rawSheetNames().map(function(v) { return runtime.getField(VS, "vs-value").app(v); })));
        })
      }));
    }
    
    function createSpreadsheet(name) {
      runtime.ffi.checkArity(1, arguments, "create-spreadsheet", false);
      runtime.checkString(name);
      return runtime.pauseStack(function(resumer) {
        sheetsAPI.then(function(api) {
          return api.createSpreadsheet(name);
        })
          .then(makePyretSpreadsheet)
          .then(function(ss) { resumer.resume(ss); })
          .catch(function(err) {
            if (runtime.isPyretException(err)) {
              resumer.error(err);
            } else {
              if (err && err.message) err = err.message;
              resumer.error(runtime.ffi.makeMessageException(err));
            }
          });
      });
    }

    function loadSpreadsheet(loader) {
      
      return runtime.pauseStack(function(resumer) {
        sheetsAPI.then(function(api) {
          SHEET_TYPES = api.TYPES;
          return loader(api);
        })
          .then(makePyretSpreadsheet)
          .then(function(ss) { resumer.resume(ss); })
          .catch(function(err) {
            if (runtime.isPyretException(err)) {
              resumer.error(err);
            } else {
              if (err && err.message) err = err.message;
              resumer.error(runtime.ffi.makeMessageException(err));
            }
          });
      });
    }

    function loadLocalSheet(name) {
      runtime.ffi.checkArity(1, arguments, 'my-spreadsheet', false);
      runtime.checkString(name);
      return loadSpreadsheet(function(api) {
        return api.loadSpreadsheetByName(name);
      });
    }

    function loadSheetById(id) {
      runtime.ffi.checkArity(1, arguments, 'load-spreadsheet', false);
      runtime.checkString(id);
      return loadSpreadsheet(function(api) {
        return api.loadSpreadsheetById(id);
      });
    }
    
    return runtime.makeModuleReturn(
      {
        'create-spreadsheet': F(createSpreadsheet, "create-spreadsheet"),
        'my-spreadsheet': F(loadLocalSheet, "my-spreadsheet"),
        'load-spreadsheet': F(loadSheetById, "load-spreadsheet"),
        // Drop the `-by-name` since this is what people will
        // probably want ~90% of the time
        'open-sheet': F(spreadsheetSheetByName, "open-sheet"),
        'open-sheet-by-index': F(spreadsheetSheetByIndex, "open-sheet-by-index")
      },
      {}
    );
  }
})

