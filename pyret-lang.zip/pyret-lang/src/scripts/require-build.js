({
    optimize: "none",
    paths: {
        'crypto': 'empty:',
        'fs': 'empty:',
        'path': 'empty:',
        'q': 'empty:',
        'requirejs': 'empty:',
        's-expression': 'empty:',
        'seedrandom': 'empty:'
      }
})

